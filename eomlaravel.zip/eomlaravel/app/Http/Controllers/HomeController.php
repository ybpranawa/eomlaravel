<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
//use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use Validator;
use Request;

class HomeController extends Controller
{
    public function login()
    {
    	if(!Auth::check())
	    {
	      return view('login');
	    }
	    else
	    {
	      return redirect('/');
	    }
    }

    public function proseslogin()
	{
		if(Request::isMethod('post'))
		{
		  	$new = Input::only('username','password');
		  	//print_r($new);
		  	//echo $new['username'];
		  	//echo "</br>".$new['password'];
		  	/*if (Auth::attempt($new,true))
			{

			$id=Auth::user()->id;
			return redirect('/');
			}
			else
			{
			Session::flash('message','Login anda gagal, silahkan cek kembali username dan password');
			return redirect('masuk');
			}*/
			if ((strtolower($new['username'])=='staff')&&($new['password']=='staff123')) {				
				$data['username']=strtolower($new['username']);
				$_SESSION['username']=$data['username'];
				return view('home',$data);
			}
			elseif ((strtolower($new['username'])=='pimpinan')&&($new['password']=='pimpinan123')) {
				$data['username']=strtolower($new['username']);
				$_SESSION['username']=$data['username'];
				return view('home',$data);
			}
			else {
				return redirect('login');
			}
		}
		elseif(Request::isMethod('get'))
		{
		  return redirect('/');
		} 
	}

	public function logout(){
		session_start();
		session_destroy();
		return redirect('/');
	}

	public function lihatproyek(){
		return view('lihatproyek');
	}

	public function tambahposting(){
		return view('tambahposting');
	}
}
